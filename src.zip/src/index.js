const WorkerService = require('./lib/WorkerService');
const loggerSetup = require('./lib/logger');

module.exports = {
    WorkerService,
    loggerSetup
}